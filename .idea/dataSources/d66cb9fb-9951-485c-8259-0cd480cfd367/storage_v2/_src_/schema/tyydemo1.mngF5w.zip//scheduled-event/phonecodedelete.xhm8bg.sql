create definer = root@localhost event PhoneCodeDelete
  on schedule
    every '1' MINUTE
      starts '2020-05-10 21:06:25'
  enable
do
  DELETE FROM phonecode
WHERE TIMESTAMPDIFF(SECOND,Time,NOW())>600;

